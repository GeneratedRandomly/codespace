### 实现思路
#### 空闲链表
- `SFL`保存$(2^{k+5},2^{k+6}]$的空闲列表
#### 内存布局
- **SFL块**
  - 空$8$字节对齐
  - $25\times2$个哨兵指针，每个$8$字节，用来构成双向循环链表
- **序言块**
  - `header`
  - `footer`
  - $16$字节
  - 已分配
- **空闲块（可能）**
  - `header`：$8$字节
    - 块大小
    - 前一块是否已分配
    - 当前块是否已分配
  - 指向空闲链表中的上一个元素的指针：$8$字节
  - 指向空闲链表中的下一个元素的指针：$8$字节
  - `footer`：$8$字节
- **已分配的块（可能）**
  - `header`：$8$字节
    - 块大小
    - 前一块是否已分配
    - 当前块是否已分配
  - `payload`
- **结尾段**
  - $0$字节
  - 已分配
#### 函数
- 所有宏都由静态内联函数和静态常量实现，保证了更强的安全性
- `PAGE_SIZE`不`const`是特判的需求
~~~c
/* ALIGNMENT = 16 byte */
static const size_t ALIGNMENT = 16; // bytes
static const size_t INFO_SIZE = 8;  // bytes
static const size_t PTR_SIZE = 8;   // bytes
static const size_t MIN_SIZE = 32;  // bytes
static size_t PAGE_SIZE = 4096;     // bytes
static const size_t WSIZE = 8;      // bytes
static const size_t PARA = 120;     // bytes
static inline size_t max(size_t x, size_t y) { return x > y ? x : y; }
static inline size_t align(size_t size) { return (size + (ALIGNMENT - 1)) & ~(ALIGNMENT - 1); }
// p starts entire block
static inline size_t get_size(void *p) { return *(size_t *)p & ~7; }                          // bytes
static inline void set_size(void *p, size_t val) { *(size_t *)p = (*(size_t *)p & 7) | val; } // bytes
static inline void *header(void *bp) { return (size_t *)bp - 1; }
static inline void *payload(void *p) { return (size_t *)p + 1; }
static inline void *footer(void *p) { return (char *)p + get_size(p) - WSIZE; }
static inline void set_footer(void *p, size_t size) { *(size_t *)footer(p) = size; }
static inline size_t prev_size(void *p) { return *((size_t *)p - 1); }
static inline void *prev_header(void *p) { return (char *)p - prev_size(p); }
static inline void *next_header(void *p) { return (char *)p + get_size(p); }
static inline size_t is_allocated(void *p) { return *(size_t *)p & 1; }
static inline void set_allocated(void *p) { *(size_t *)p |= 1; }
static inline void unset_allocated(void *p) { *(size_t *)p &= ~1; }
static inline size_t is_prev_allocated(void *p) { return *(size_t *)p & 2; }
static inline void set_prev_allocated(void *p) { *(size_t *)p |= 2; }
static inline void unset_prev_allocated(void *p) { *(size_t *)p &= ~2; }
// 内建函数用于计算前导零，这个内联函数和while右移循环除2算log2效果相同
static inline size_t log2size_t(size_t size) { return 63 - __builtin_clzll(size - 1); }
/* sfl: [2^0,2^1),...,[2^24,2^25), totally 25 pointers as headguard, 0~24*/
// empty, prev0, next0, ..., prev24, next24, prologue head, prologue end, epilogue head.
// segerated free list
static const size_t SFL_PTR_CNT = 25;
// the guard is fake and shall not be real visited. k is index, representing (2^(k+5) ~ 2^(k+6)]
static inline void *guard(size_t k) { return (size_t *)mem_heap_lo() + (k << 1); }
static inline void **prev_free(void *p) { return (void **)p + 1; }
static inline void **next_free(void *p) { return (void **)p + 2; }
~~~
- 其中，哨兵指针存在于“假的”地址，真正的指针只有哨兵的`perv`和`next`。
- `remove_from_sfl`和`insert_into_sfl`是简单的链表插入和删除，后者多一个插入链表尾所以要按照`size`算$\log_2$找链表。
~~~c
static void remove_from_sfl(void *p)
{
  *next_free(*prev_free(p)) = *next_free(p);
  *prev_free(*next_free(p)) = *prev_free(p);
}
static void insert_into_sfl(void *p)
{
  void *guardptr = guard(log2size_t(get_size(p)));
  void *prevptr = *prev_free(guardptr);
  *prev_free(p) = prevptr;
  *next_free(prevptr) = p;
  *next_free(p) = guardptr;
  *prev_free(guardptr) = p;
}
~~~
- `find_fit`：在`SFL`里应用`first_fit`（也就是最佳匹配了），从大小能容纳的最小`SFL`链表开始，沿着链表寻找，找不到换更大区间的链表，直到找到一个可以容纳的空闲块。否则返回空指针。
~~~c
static void *find_fit(size_t size)
{
  for (size_t k = log2size_t(size); k < SFL_PTR_CNT; k++)
  {
    void *guardk = guard(k);
    void *it = *next_free(guardk);
    while (it != guardk)
    {
      if (get_size(it) >= size)
        return it;
      it = *next_free(it);
    }
  }
  return NULL;
}
~~~
- 合并函数：先把后面的空闲块（如有）合并，直接修改`alloc`情况和`size`大小即可；否则试图合并前面的空闲块，这样还要更改指针指向位置。由于是空闲块合并，要设置`footer`。每次`free`和`realloc`都会合并，所以保证空闲块两边必定是已分配块。
~~~c
static void *coalesce(void *hp)
{
  size_t size = get_size(hp);
  // next
  void *freeptr = next_header(hp);
  if (!is_allocated(freeptr))
  {
    size += get_size(freeptr);
    remove_from_sfl(freeptr);
  }
  // prev
  if (!is_prev_allocated(hp))
  {
    freeptr = prev_header(hp);
    size += get_size(freeptr);
    remove_from_sfl(freeptr);
    hp = freeptr;
  }
  // update
  set_size(hp, size);
  set_prev_allocated(hp);
  unset_allocated(hp);
  set_footer(hp, size);
  return hp;
}
~~~
- 扩展堆函数：在`mm_malloc`找不到空闲块时调用，注意`mem_sbrk`的返回值其实是有一个原来结尾块导致的偏移量，需要往前跳一个，设置`size`之后设置新的结尾块。原来的结尾有可能是空闲块，所以合并。
~~~c
static void *extend(size_t size)
{
  size_t *p = mem_sbrk(size);
  if ((void *)(-1) == p)
    return NULL;
  p--; // jump over epilogue head
  set_size(p, size);
  set_size(next_header(p), 0);
  set_allocated(next_header(p));
  return coalesce(p);
}
~~~
- `place`和`split`，都是在一个大空闲块里切割出一部分为分配块，另一部分保留空闲，区别仅在于前者的分配块靠前而空闲块靠后，后者的空闲块靠前而分配块靠后。
~~~c
// hp is in front of the block
static void *place(void *hp, size_t size)
{
  size_t oldsize = get_size(hp);
  size_t leftsize = oldsize - size;
  if (leftsize >= MIN_SIZE)
  {
    set_size(hp, size);
    set_allocated(hp);
    void *p2 = next_header(hp);
    set_size(p2, leftsize);
    unset_allocated(p2);
    set_prev_allocated(p2);
    set_footer(p2, leftsize);
    insert_into_sfl(p2);
  }
  return hp;
}
// hp is at rear of the block
static void *split(void *hp, size_t size)
{
  size_t oldsize = get_size(hp);
  size_t leftsize = oldsize - size;
  if (leftsize >= MIN_SIZE)
  {
    set_size(hp, leftsize);
    unset_allocated(hp);
    set_footer(hp, leftsize);
    insert_into_sfl(hp);
    hp = next_header(hp);
    set_size(hp, size);
    set_allocated(hp);
    unset_prev_allocated(hp);
    set_prev_allocated(next_header(hp));
  }
  return hp;
}
~~~
#### 四个mem函数
- `mem_init`：先开指针、序言块、结尾块大小的数组，设置相关变量；让各个哨兵的`prev`和`next`指针都指向哨兵自己，开始双向循环链表。然后设置相关信息。
- `mem_malloc`：先从`sfl`里找可以使用的空闲块，找到就把它从`sfl`里删除；否则开一块新的内存，稍微开大到$4096$，避免大量开内存请求和内存碎片化。然后是对于大块分配块往后放，小块往前放，是参考资料的优化方法，能够减少外部碎片化。这里和`realloc`里意义不明的内容属于针对`trace`的特判，一部分是从参考资料3里学到的，也有自己开的。特判`size==4092`是针对`realloc2`，会直接开大，避开$16$字节小块挡道，`char a`就表示遇到了这种情况，让大块在前，小块在最后，互不影响。同时改小`PAGE_SIZE`以免开太大页产生无效空间。
- `mem_free`：合并空闲块，插入`sfl`，告知下一块即可。
- `mem_realloc`：如果要缩小，直接`place`即可。否则，我们先试图就地`realloc`，使用当前块前后的空闲块来试图容纳增大了的`size`。如果后面的空闲块就够了，直接合并上再`place`；否则，试探前面的空闲块。如果够了，设置相关信息，把`header`以外的部分往前`memmove`过来再`place`。如果这也失败了，就必须新开一块，主要是调用一下`mm_malloc`分配一块来，并且进行`memcpy`，同时把原来的加入`sfl`。这里也有特判，是从参考资料3里学习的。
### 实验结果
#### 本机：
~~~
Results for mm malloc:
trace            name     valid  util     ops      secs   Kops
 1     amptjp-bal.rep       yes   99%    5694  0.000157  36360
 2       cccp-bal.rep       yes   99%    5848  0.000167  35123
 3    cp-decl-bal.rep       yes   99%    6648  0.000193  34410
 4       expr-bal.rep       yes   99%    5380  0.000148  36425
 5 coalescing-bal.rep       yes   95%   14400  0.000241  59652
 6     random-bal.rep       yes   95%    4800  0.000168  28640
 7    random2-bal.rep       yes   94%    4800  0.000160  30019
 8     binary-bal.rep       yes   94%   12000  0.000264  45455
 9    binary2-bal.rep       yes   81%   24000  0.000579  41429
10    realloc-bal.rep       yes   99%   14401  0.000298  48245
11   realloc2-bal.rep       yes   98%   14401  0.000244  59020
Total                             96%  112372  0.002619  42911

Score = (57 (util) + 40 (thru)) * 11/11 (testcase) = 59/100
~~~
#### ics24服务器：
~~~
Results for mm malloc:
trace            name     valid  util     ops      secs   Kops
 1     amptjp-bal.rep       yes   99%    5694  0.000294  19374
 2       cccp-bal.rep       yes   99%    5848  0.000286  20440
 3    cp-decl-bal.rep       yes   99%    6648  0.000348  19087
 4       expr-bal.rep       yes   99%    5380  0.000286  18831
 5 coalescing-bal.rep       yes   95%   14400  0.000437  32982
 6     random-bal.rep       yes   95%    4800  0.000363  13230
 7    random2-bal.rep       yes   94%    4800  0.000283  16943
 8     binary-bal.rep       yes   94%   12000  0.000418  28722
 9    binary2-bal.rep       yes   81%   24000  0.000750  32009
10    realloc-bal.rep       yes   99%   14401  0.000400  36039
11   realloc2-bal.rep       yes   98%   14401  0.000288  49934
Total                             96%  112372  0.004152  27063

Score = (57 (util) + 40 (thru)) * 11/11 (testcase) = 59/100
~~~
### 参考资料
[malloc lab报告1](https://github.com/leverimmy/Introduction-to-Computer-Systems-Labs/blob/main/malloc-lab/REPORT.md)  
[malloc lab报告2](https://github.com/ouuan/course-assignments/blob/master/csapp/malloc-lab/README.md)  
[malloc lab报告3](https://github.com/zhangchi2004/ICS-2023/blob/main/malloclab/report.pdf)  
[malloc lab报告北大版](https://arthals.ink/blog/malloc-lab)  
csapp
### 感想体验
有前人经验带领很重要，特判可以提升很多分数，但人力有时尽，在种种客观条件限制之下也要学会接受不完美，比如`binary2-bal.rep`。
### 优化方向
现在$16B$的块一定要扩到$32B$，应该有一个小区间用另一种体系储存和访问小于等于$16B$的块，这样`binary2`会有很大提高。或者用`int`记录针对`mem_heap_lo`的偏移量，或者只记录指针的后$4B$等空间节约方法。